<?php 
/*
 * Banner Code Template for the Sidebar
 *
 * It is recommended to set up a child theme and copy this file inside your child theme folder.
 * In this case, any code you put in here will not be lost once you update Newswire theme.
 */ 
?>

<!-- Add Banner Code Below This Comment (max. 300px wide) -->
