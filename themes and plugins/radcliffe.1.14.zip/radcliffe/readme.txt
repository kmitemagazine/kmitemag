Copyright
--------------

Radcliffe WordPress Theme, Copyright 2014 Anders Norén
Radcliffe is distributed under the terms of the GNU GPL v2


Install Steps
--------------

1. Upload the theme
2. Activate the theme


Licenses
--------------

Font Awesome icons license : SIL Open Font License 1.1 http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL

Open Sans font license : SIL Open Font License, 1.1 http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL

Crimson Text font license : SIL Open Font License, 1.1 http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL

Abril Fatface font license : SIL Open Font License, 1.1 http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL

Backstretch.js Javascript plugin license : MIT License https://raw.githubusercontent.com/srobbin/jquery-backstretch/master/LICENSE-MIT

screenshot.png post images license : Public Domain (CC0) http://en.wikipedia.org/wiki/Public_domain