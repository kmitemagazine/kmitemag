var $issuem_custom_tax_hack = jQuery.noConflict();

$issuem_custom_tax_hack(document).ready(function($) {
	
	$( 'div#issuem_issue-adder' ).css( 'display', 'none' );
	
});